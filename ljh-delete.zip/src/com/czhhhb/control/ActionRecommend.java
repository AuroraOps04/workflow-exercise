package com.czhhhb.control;

import com.czhhhb.db.Dbobject;
import com.czhhhb.model.Book;

import javax.swing.*;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.swing.text.StyledDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ActionRecommend implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        JFrame frame =new JFrame();
        frame.setTitle("推荐图书");
        Dbobject dbobject =new Dbobject();
        ArrayList<Book> book =dbobject.recommend();

        String[] columnNames =
                {"num","name", "IBSN"};
        Object[][] obj = new Object[book.size()][3];
        int i=0;
        for (Book x : book) {
            obj[i][0]=x.getNum();
            obj[i][1]=x.getName();
            obj[i][2]=x.getIBSN();
            i++;
        }
        JTable jtable = new JTable(obj,columnNames);
        TableColumn column = null;
        int colunms = jtable.getColumnCount();
        for(i = 0; i < colunms; i++)
        {
            column = jtable.getColumnModel().getColumn(i);
            /*将每一列的默认宽度设置为100*/
            column.setPreferredWidth(30);
        }

        JScrollPane scroll = new JScrollPane(jtable);
        scroll.setSize(90,50);
        frame.add(scroll);
        frame.setLocation(800, 450);
        frame.setSize(300, 200);
        frame.setVisible(true);
    }
        //实现图书推荐功能，监听实现gui 并且调用数据库操作
        //随机产生一批图书产生到界面上，界面自己做 也可以参考图书查看的界面
}
