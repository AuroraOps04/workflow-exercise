package com.czhhhb.control;

import com.czhhhb.db.Dbobject;
import com.czhhhb.model.Book;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionChange implements ActionListener {
    public class frame2 extends JFrame {
        private JTextField text = new JTextField(20);
        JButton buttonseek=new JButton("更新");
        JLabel lblNewLabel = new JLabel("请输入要更新的书号：");
        private JPanel contentPane;
        public frame2() {
            super("信息更新");
            setSize(400, 150);
            setLocationRelativeTo(null);
            contentPane=new JPanel();
            lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 20));
            lblNewLabel.setBounds(198, 37, 100, 43);
            contentPane.add(lblNewLabel);
            setContentPane(contentPane);
            text.setBounds(250,37,100,100);
            add(text);
            add(buttonseek);
            setVisible(true);
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //实现图书信息修改功能，监听实现gui 并且调用数据库操作
        //先输入图书的编号，如果数据库有这本书则产生更新界面，去修改数据
        //如果编号不存在，则出现界面提示不存在
        frame2 frame=new frame2();
        frame.buttonseek.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                Dbobject db=new Dbobject();
                if(db.SeekBook(frame.text.getText()).size()==1)
                {
                    JFrame jframe=new JFrame();
                    jframe.setTitle("更新信息");
                    jframe.setSize(350, 300);
                    JLabel JLabel_number = new JLabel("书号：");
                    JLabel JLabel_name = new JLabel("书名：");
                    JLabel JLabel_IBSN = new JLabel("IBSN: ");

                    JTextField JText_number = new JTextField(frame.text.getText(), 20);
                    JText_number.setEditable(false);
                    JTextField JText_name = new JTextField("", 20);
                    JTextField JText_IBSN = new JTextField("", 20);

                    JPanel JPanel_number =new JPanel();
                    JPanel JPanel_name =new JPanel();
                    JPanel JPanel_IBSN =new JPanel();

                    JPanel_number.setBounds(0, 1, 336, 29);
                    JPanel_name.setBounds(0, 28, 336, 29);
                    JPanel_IBSN.setBounds(0, 55, 336, 29);

                    JPanel_number.add(JLabel_number);
                    JPanel_number.add(JText_number);

                    JPanel_name.add(JLabel_name);
                    JPanel_name.add(JText_name);

                    JPanel_IBSN.add(JLabel_IBSN);
                    JPanel_IBSN.add(JText_IBSN);

                    JButton buttonadd = new JButton("更新");
                    JButton buttonreturn = new JButton("返回");//按钮添加


                    buttonadd.setBounds(0, 224, 168, 29);
                    buttonreturn.setBounds(168, 224, 168, 29);//设置按钮位置

                    buttonadd.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {//设置监听
                            Dbobject db=new Dbobject();
                            Book st=new Book();
                            st.setNum(JText_number.getText());
                            st.setName(JText_name.getText());
                            st.setIBSN(JText_IBSN.getText());
                            JFrame newframe=new JFrame();
                            newframe.setSize(240, 120);
                            newframe.setLocation(700, 450);
                            JLabel lable = new JLabel("更新成功!");
                            lable.setBounds(70, 13, 60, 60);
                            newframe.add(lable);
                            newframe.setLayout(null);
                            newframe.setLocationRelativeTo(null);
                            newframe.setVisible(true);
                            db.change(st);
                        }
                    });
                    buttonreturn.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {//设置监听
                            jframe.dispose();
                        }
                    });//设置监听 点击退出按钮直接销毁窗体

                    jframe.getContentPane().add(JPanel_number);
                    jframe.getContentPane().add(JPanel_name);
                    jframe.getContentPane().add(JPanel_IBSN);
                    jframe.getContentPane().add(buttonadd);
                    jframe.getContentPane().add(buttonreturn);//增加组件
                    jframe.setLayout(null);
                    jframe.setLocationRelativeTo(null);
                    jframe.setVisible(true);
                }

                else//失败提示
                {
                    JFrame newframe=new JFrame();
                    newframe.setSize(240, 120);
                    newframe.setLocation(700, 450);
                    JLabel lable = new JLabel("无此书号!");
                    lable.setBounds(70, 13, 60, 60);
                    newframe.add(lable);
                    newframe.setLayout(null);
                    newframe.setLocationRelativeTo(null);
                    newframe.setVisible(true);
                }
            }
        });
    }
}
